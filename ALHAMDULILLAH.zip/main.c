#include "windows_api.c"
#include "tampilan.c"
#include "login.c"
#include "pilihan.c"

//////////////////////////////////////////////////////////////////////////
//       NAMA     : ALIYA ROHAYA SIREGAR                                //
//       FAKULTAS : ILMU KOMPUTER                                       //
//       PRODI    : D3 MI                                               //
//       ANGKATAN 20 PUB (INTEGER)                                      //
//       PELATIH  : BG DANI HIDAYAT DAN MBAK NUSROTUMMILLAH NURUL'AINI  //
//////////////////////////////////////////////////////////////////////////

void main(){   

login();
menu_utama();


    // pause();
}
